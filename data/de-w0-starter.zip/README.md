# Week 0 Starter — DE Projects

## Quick start
1) Install **uv** (optional but recommended): https://docs.astral.sh/uv/getting-started/  
   macOS/Linux:
   ```bash
   curl -LsSf https://astral.sh/uv/install.sh | sh
   ```

2) Create venv & install:
   ```bash
   uv venv
   uv sync
   ```

3) Prepare env:
   ```bash
   cp .env.example .env  # edit values
   ```

4) Run demo:
   ```bash
   make demo
   ```

5) Run Bash mini exercises:
   ```bash
   bash scripts/w0_bash_exercises.sh
   ```

6) Lint / type / test:
   ```bash
   make lint
   make type
   make test
   ```

7) Enable pre-commit (secrets scan + ruff):
   ```bash
   uv add --dev pre-commit detect-secrets ruff mypy pytest
   pre-commit install
   pre-commit run --all-files
   ```

## Git flow (local → GitHub)
```bash
git init -b main
git add . && git commit -m "chore: init w0 starter"

# create feature branch, commit
git switch -c feat/w0-bash
# ...edit files...
git add . && git commit -m "feat(w0): bash exercises"
# push to your GitHub repo (replace URL)
git remote add origin https://github.com/<you>/de-projects.git
git push -u origin feat/w0-bash

# open PR (with GitHub CLI)
gh pr create --fill --base main --head feat/w0-bash

# simulate rebase workflow (after main moved ahead)
git switch feat/w0-bash
git fetch origin
git rebase origin/main
# resolve conflicts if any, then:
git push --force-with-lease
```
